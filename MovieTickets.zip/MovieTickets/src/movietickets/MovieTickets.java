
package movietickets;


public class MovieTickets {

    public static void main(String[] args) {
     Mainscreen ms=   new Mainscreen();
             ms.setVisible(true);
            
        

    }
    
}
